<?php include 'includes/header.php' ?>

 <!-- di page composer css -->

 <style>
    header ul li a{
        color: black !important;
    }
 </style>
 <style id='di-page-composer-styles'>
        .txt-size {
            font-size: 15px
        }
    </style>
    <!-- eof: di page composer css -->
    <style>
        .dipc-password-protection {
            text-align: center;
            padding: 5% 0;
        }

        .dipc-password-protection form {
            display: inline-block;
        }
    </style>
    <div class="new7">
    <div id="di-page-composer" class="modelpagebuilder contentcontainer" >
        <div id="" class=" fullcontentrow bgimagerow dark-text cover" style="background-size:cover;background-repeat:no-repeat;width:100%">
            <div class="  container-wide ">
                <div class="row">
                    <div class="col-xs-12 inner-wysiwyg">
                        <p>
                            <iframe loading="lazy" title="" src="https://app.mykaarma.com/consumer/embedded.html?uid=43cdd779972e2efd83c76dd63f02ecb561df1dff0dfb473259f79adaab189c00#appointment_online_start_page" width="100%" height="750" frameborder="0"></iframe>
                        </p>
                        <p>If you know you have a Recall on your vehicle, please call our service team to schedule your appointment so we can make sure the parts needed will be in stock when you bring your BMW in.</p>
                        <p>If you need a Courtesy Vehicle, please call our service team to schedule your appointment so we can reserve this for you.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

</div>
   

    <?php include 'includes/footer.php' ?>
    <!--  -->
    <!--  -->